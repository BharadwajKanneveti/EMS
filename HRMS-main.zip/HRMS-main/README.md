This ia Human Resource Management System which have features like employee management, attendance management, payroll management
Project Link:
https://calm-bastion-29168.herokuapp.com/landing_page
